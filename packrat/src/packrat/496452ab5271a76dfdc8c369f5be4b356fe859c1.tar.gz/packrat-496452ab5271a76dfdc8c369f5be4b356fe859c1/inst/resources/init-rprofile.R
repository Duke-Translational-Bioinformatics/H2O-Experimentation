#### -- Packrat Autoloader (version 0.4.0.8) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
